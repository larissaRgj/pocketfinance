package aula06metodo;
/**
 * @author Wanderson Santos
 */
public class CartaoDeCredito {
    int numero;
    String dataDeValidade;

    // Criar o relacionamento do Cartão com o Cliente
    Cliente cliente;

    // Métodos para o atributo 'numero'
    public void setNumero(int num) {
        numero = num;
    }

    public int getNumero() {
        return numero;
    }

    // Métodos para o atributo 'dataDeValidade'
    public void setDataDeValidade(String dtVal) {
        dataDeValidade = dtVal;
    }

    public String getDataDeValidade() {
        return dataDeValidade;
    }
}
