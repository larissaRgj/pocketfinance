package aula06metodo;
/**
 * @author Wanderson Santos
 */
public class Conta {

    double saldo;
    double limite = 800;
    int numero;

    // Criar o relacionamento da Conta com a Agencia
    Agencia agencia;

    public void setSaldo(double s) {
        saldo = s;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setLimite(double l) {
        limite = l;
    }

    public double getLimite() {
        return limite;
    }

    public void setNumero(int n) {
        numero = n;
    }

    public int getNumero() {
        return numero;
    }
}
