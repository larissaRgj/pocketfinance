package aula06metodo;
/**
 * @author Wanderson Santos
 */
public class Agencia {
    
    int numero;
    String uf;

    // Métodos para o atributo 'numero'
    public void setNumero(int num) {
        numero = num;
    }

    public int getNumero() {
        return numero;
    }

    // Métodos para o atributo 'uf'
    public void setUF(String siglaEstado) {
        uf = siglaEstado;
    }

    public String getUF() {
        return uf;
    }
}