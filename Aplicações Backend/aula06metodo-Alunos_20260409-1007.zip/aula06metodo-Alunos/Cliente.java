package aula06metodo;
/**
 * @author Wanderson Santos
 */
public class Cliente {
    String nome;
    int codigo;

    public void setNome(String n) {
        nome = n;
    }

    public String getNome() {
        return nome;
    }

    public void setCodigo(int c) {
        codigo = c;
    }

    public int getCodigo() {
        return codigo;
    }
}